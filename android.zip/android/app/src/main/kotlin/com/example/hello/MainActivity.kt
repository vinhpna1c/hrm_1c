package com.example.hello

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
